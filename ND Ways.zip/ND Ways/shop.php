<?php
	session_start();
	$host = "localhost";
	$username = "root";
	$password = "";
	$database = "cart";
	$conn = mysqli_connect($host,$username,$password,$database);

	if(isset($_POST["add"])){
		if(isset($_SESSION['cart'])){
			$item_array_id = array_column($_SESSION["cart"], column_key: "product_id");
			if(!in_array($_GET['id'],$item_array_id)){
				$count = count($_SESSION['cart']);
				$item_array = array(
					'product_id' => $_GET['id'],
					'item_name' => $_POST['hidden_name'],
					'product_price' => $_POST['hidden_price'],
					'item_quantity' => $_POST['quantity'],
				);
				$_SESSION['cart'][$count] = $item_array;
				echo '<script>window.location="shop.php"</script>';
			}
			else{
				echo '<script>alert("Product is already added to cart")</script>';
				echo '<script>window.location="shop.php"</script>';
			}
		}
		else{
			$item_array = array(
				'product_id' => $_GET['id'],
				'item_name' => $_POST['hidden_name'],
				'product_price' => $_POST['hidden_price'],
				'item_quantity' => $_POST['quantity'],
			);
			$_SESSION["cart"][0] = $item_array;
		}
	}

	if(isset($_GET['action'])){
		if($_GET["action"] == "delete"){
			foreach($_SESSION["cart"] as $keys => $value){
				if($value["product_id"] == $_GET["id"]){
					unset($_SESSION["cart"][$keys]);
					echo '<script>alert("Product has been removed..")</script>';
					echo '<script>window.location="shop.php"</script>';
				}
			}
		}
	}
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Responsive Bootstrap4 Shop Template, Created by Imran Hossain from https://imransdesign.com/">

	<!-- title -->
	<title>Shop</title>

	<!-- favicon -->
	<link rel="shortcut icon" type="image/png" href="assets/img/favicon.png">
	<!-- google font -->
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Poppins:400,700&display=swap" rel="stylesheet">
	<!-- fontawesome -->
	<link rel="stylesheet" href="assets/css/all.min.css">
	<!-- bootstrap -->
	<link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
	<!-- owl carousel -->
	<link rel="stylesheet" href="assets/css/owl.carousel.css">
	<!-- magnific popup -->
	<link rel="stylesheet" href="assets/css/magnific-popup.css">
	<!-- animate css -->
	<link rel="stylesheet" href="assets/css/animate.css">
	<!-- mean menu css -->
	<link rel="stylesheet" href="assets/css/meanmenu.min.css">
	<!-- main style -->
	<link rel="stylesheet" href="assets/css/main.css">
	<!-- responsive -->
	<link rel="stylesheet" href="assets/css/responsive.css">
	<style>
		.product{
			border: 1px solid #eaeaec;
			margin: -1px 19px 3px -1px;
			padding: 10px;
			text-align: center;
			background-color: #efefef;
		}
		table, th, tr{
			text-align: center;
		}
		.title2{
			text-align: center;
			color: #66afe9;
			background-color: #efefef;
			padding: 2%;
		}
		h2{
			text-align: center;
			color: #66afe9;
			background-color: #efefef;
			padding: 2%;
		}
		table th{
			background-color: #efefef;
		}
	</style>

</head>
<body>
	
	<!--PreLoader-->
    <div class="loader">
        <div class="loader-inner">
            <div class="circle"></div>
        </div>
    </div>
    <!--PreLoader Ends-->
	
	<!-- header -->
	<div class="top-header-area" id="sticker">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-sm-12 text-center">
					<div class="main-menu-wrap">
						<!-- logo -->
						<div class="site-logo">
							<a href="index.html">
								<img src="assets/img/logo-1.png" alt="">
							</a>
						</div>
						<!-- logo -->

						<!-- menu start -->
						<nav class="main-menu">
							<ul>
								<li class="current-list-item"><a href="#">Home</a>
									<ul class="sub-menu">
										<li><a href="index.html">ND Home</a></li>
									</ul>
								</li>
								<li><a href="about.html">About</a></li>
								<li><a href="#">Pages</a>
									<ul class="sub-menu">
										<li><a href="404.html">404 page</a></li>
										<li><a href="signup.php">Sign Up</a></li>
										<li><a href="login.php">Log in</a></li>
									</ul>
								</li>
								<li><a href="#">News</a>
									<ul class="sub-menu">
										<li><a href="news.html">News</a></li>
										<li><a href="single-news.html">Single News</a></li>
									</ul>
								</li>
								<li><a href="contact.php">Contact</a></li>
								<li><a href="shop.html">Shop</a>
									<ul class="sub-menu">
										<li><a href="shop.html">Shop</a></li>
										<li><a href="checkout.html">Check Out</a></li>
										
									</ul>
								</li>
								<li>
									<div class="header-icons">
										<a class="shopping-cart" href="cart.html"><i class="fas fa-shopping-cart"></i></a>
										<a class="mobile-hide search-bar-icon" href="#"><i class="fas fa-search"></i></a>
									</div>
								</li>
							</ul>
						</nav>
						<a class="mobile-show search-bar-icon" href="#"><i class="fas fa-search"></i></a>
						<div class="mobile-menu"></div>
						<!-- menu end -->
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- end header -->

	<!-- search area -->
	<div class="search-area">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<span class="close-btn"><i class="fas fa-window-close"></i></span>
					<div class="search-bar">
						<div class="search-bar-tablecell">
							<h3>Search For:</h3>
							<input type="text" placeholder="Keywords">
							<button type="submit">Search <i class="fas fa-search"></i></button>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- end search arewa -->
	
	<!-- breadcrumb-section -->
	<div class="breadcrumb-section breadcrumb-bg">
		<div class="container">
			<div class="row">
				<div class="col-lg-8 offset-lg-2 text-center">
					<div class="breadcrumb-text">
						<p>Smart and new</p>
						<h1>Shop</h1>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- end breadcrumb section -->

	<!-- products -->
	<div class="product-section mt-150 mb-150">
		<div class="container">

			<div class="row">
                <div class="col-md-12">
                    <div class="product-filters">
                        <ul>
							<!--
                            <li class="active" data-filter="*">All</li>
                            <li data-filter=".strawberry">Raspberry pi 3</li>
                            <li data-filter=".berry">Raspberry pi 4</li>
							-->
                            <li data-filter=".lemon">ALL</li>
                        </ul>
                    </div>
                </div>
            </div>
			<?php
				$query = "select * from cart order by id asc";
				$result = mysqli_query($conn,$query);
				if(mysqli_num_rows($result) > 0){

					while($row = mysqli_fetch_array($result)){		
				
			?>
			<div class="col-mdd-3">
					<form method="POST" action="shop.php?action=add&id=<?php echo $row["id"] ?>">

						<div class="product">
							<img src="<?php echo $row["image"]; ?>" class="img-responsive">
							<h5 class="text-info"><?php echo $row["pname"]; ?></h5>
							<h5 class="text-danger"><?php echo $row["price"]; ?></h5>
							<input type="text" name="quantity" class="form-control" value="1">
							<input type="hidden" name="hidden_name" value="<?php echo $row["pname"]; ?>">
							<input type="hidden" name="hidden_price" value="<?php echo $row["price"]; ?>">
							<input type="submit" name="add" style="margin-top: 5px;" class="btn btn-success" value="Add to cart">
						</div>
					</form>
			</div>
			<?php
					}
				}
			?>
			<div style="clear: both"></div>
			<h3 class="title2">Shopping Cart Details</h3>
			<div class="table-responsive">
				<table class="table table-bordered">
				<tr>
					<th width="30%">Product Name</th>
					<th width="10%">Quantity</th>
					<th width="13%">Price Details</th>
					<th width="10%">Total Price</th>
					<th width="17%">Remove Item</th>
				</tr>

				<?php
					if(!empty($_SESSION["cart"])){
						$total = 0;
						foreach($_SESSION["cart"] as $key => $value){
							?>
					<tr>
						<td><?php echo $value["item_name"]; ?></td>
						<td><?php echo $value["item_quantity"]; ?></td>
						<td><?php echo $value["product_price"]; ?></td>
						<td><?php echo number_format($value["item_quantity"] * $value["product_price"], decimals:2); ?></td>
						<td><a href="shop.php?action=delete&id=<?php echo $value["product_id"]; ?>"><span class="text-danger">Remover Item</span></a></td>
					</tr>
					<?php
						$total = $total + ($value["item_quantity"] * $value["product_price"]);
					}
					?>
					<tr>
						<td colspan="3" align="right">Total</td>
						<th align="right"><?php echo number_format($total, decimals:2); ?></th>
					</tr>
					<?php
					}
				?>
				</table>
			</div>
		</div>
	</div>


			

	<!-- logo carousel -->
	<!--
	<div class="logo-carousel-section">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="logo-carousel-inner">
						<div class="single-logo-item">
							<img src="assets/img/company-logos/1.png" alt="">
						</div>
						<div class="single-logo-item">
							<img src="assets/img/company-logos/2.png" alt="">
						</div>
						<div class="single-logo-item">
							<img src="assets/img/company-logos/3.png" alt="">
						</div>
						<div class="single-logo-item">
							<img src="assets/img/company-logos/4.png" alt="">
						</div>
						<div class="single-logo-item">
							<img src="assets/img/company-logos/5.png" alt="">
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
-->
	<!-- end logo carousel -->

	<!-- footer -->
	<div class="footer-area">
		<div class="container">
			<div class="row">
				<div class="col-lg-3 col-md-6">
					<div class="footer-box about-widget">
						<h2 class="widget-title">About us</h2>
						<p>These plateform will provide that enveiroment people where they can work on their start-up. It is like book hotel online. User have to book room regarding their time periods.This plateform provides technical things and other stuff regarding user's project.</p>
					</div>
				</div>
				<div class="col-lg-3 col-md-6">
					<div class="footer-box get-in-touch">
						<h2 class="widget-title">Get in Touch</h2>
						<ul>
							<li>18, East bungalow, New palace road, Germany.</li>
							<li>djsalvi1424@gmail.com</li>
							<li>+91 9099071935</li>
						</ul>
					</div>
				</div>
				<div class="col-lg-3 col-md-6">
					<div class="footer-box pages">
						<h2 class="widget-title">Pages</h2>
						<ul>
							<li><a href="index.html">Home</a></li>
							<li><a href="about.html">About</a></li>
							<li><a href="shop.html">Shop</a></li>
							<li><a href="news.html">News</a></li>
							<li><a href="contact.html">Contact</a></li>
						</ul>
					</div>
				</div>
				<div class="col-lg-3 col-md-6">
					<div class="footer-box subscribe">
						<h2 class="widget-title">Subscribe</h2>
						<p>Subscribe to our mailing list to get the latest updates.</p>
						<form action="index.html">
							<input type="email" placeholder="Email">
							<button type="submit"><i class="fas fa-paper-plane"></i></button>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- end footer -->
	
	<!-- copyright -->
	<div class="copyright">
		<div class="container">
			<div class="row">
				<div class="col-lg-6 text-right col-md-12">
					<div class="social-icons">
						<ul>
							<li><a href="#" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
							<li><a href="#" target="_blank"><i class="fab fa-twitter"></i></a></li>
							<li><a href="#" target="_blank"><i class="fab fa-instagram"></i></a></li>
							<li><a href="#" target="_blank"><i class="fab fa-linkedin"></i></a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- end copyright -->
	
	<!-- jquery -->
	<script src="assets/js/jquery-1.11.3.min.js"></script>
	<!-- bootstrap -->
	<script src="assets/bootstrap/js/bootstrap.min.js"></script>
	<!-- count down -->
	<script src="assets/js/jquery.countdown.js"></script>
	<!-- isotope -->
	<script src="assets/js/jquery.isotope-3.0.6.min.js"></script>
	<!-- waypoints -->
	<script src="assets/js/waypoints.js"></script>
	<!-- owl carousel -->
	<script src="assets/js/owl.carousel.min.js"></script>
	<!-- magnific popup -->
	<script src="assets/js/jquery.magnific-popup.min.js"></script>
	<!-- mean menu -->
	<script src="assets/js/jquery.meanmenu.min.js"></script>
	<!-- sticker js -->
	<script src="assets/js/sticker.js"></script>
	<!-- main js -->
	<script src="assets/js/main.js"></script>

</body>
</html>